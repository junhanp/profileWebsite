I created this website using replit.com

The link is: https://replit.com/talk/share/Profile-Demo/132069
Fullsite look: https://Profile-Demo.junhanpang.repl.co

You can also run this website yourself using HTML editors.
The firefox files are HTML and need to open it with a text editor like notepad to see the code.
Same with the script(javascript) and style(CSS) file.

Everything here is just a demo with demo text and pictures as of right now.