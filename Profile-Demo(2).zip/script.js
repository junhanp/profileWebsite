/* Set the width of the sidebar to 250px (show it) */
function openNav() {
  document.getElementById("Sidepanel").style.width = "200px";
}

/* Set the width of the sidebar to 0 (hide it) */
function closeNav() {
  document.getElementById("Sidepanel").style.width = "0";
} 

var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var content = this.nextElementSibling;
    if (content.style.maxHeight){
      content.style.maxHeight = null;
    } else {
      content.style.maxHeight = 100*(content.scrollHeight) + "px"; /* the higher the number the more collapsible possible within the collapsible if run out of space, multiply a higher number right now about <100 collapsible can be within one collapsible */
    } 
  });
}